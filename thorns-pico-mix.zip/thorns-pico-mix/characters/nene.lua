luaDebugMode=true
function onCreatePost()
callMethod('gf.origin.set', {50,45})
end

makeAnimatedLuaSprite('abotHead', 'characters/abotPixel/abotHead',getProperty('gfGroup.x')-240, getProperty('gfGroup.y')+200)
addAnimationByPrefix('abotHead', 'toleft', 'toleft0', 24, false)
addAnimationByPrefix('abotHead', 'toright', 'toright0', 24, false)
scaleObject('abotHead', 6, 6)
setProperty('abotHead.antialiasing', false)
addLuaSprite('abotHead')

makeAnimatedLuaSprite('abotSpeaker', 'characters/abotPixel/aBotPixelSpeaker',getProperty('gfGroup.x')-238,getProperty('gfGroup.y')+120)
addAnimationByPrefix('abotSpeaker', 'danceLeft', 'danceLeft', 24, false)
scaleObject('abotSpeaker', 6, 6)
callMethod('abotSpeaker.origin.set', {callMethodFromClass('Math', 'round', {getProperty('abotSpeaker.origin.x')}),callMethodFromClass('Math', 'round', {getProperty('abotSpeaker.origin.y')})}) 
setProperty('abotSpeaker.antialiasing', false)
addLuaSprite('abotSpeaker')

createInstance('abot', 'states.stages.objects.ABotSpeaker', {getProperty('gfGroup.x'), getProperty('gfGroup.y')+100})
addInstance('abot')
setProperty('abot.eyeBg.visible', false)
setProperty('abot.eyes.visible', false)
setProperty('abot.speaker.visible', false)
loadGraphic('abot.bg', 'characters/abotPixel/aBotPixelBack')
scaleObject('abot.bg', 6, 6)
setProperty('abot.bg.antialiasing', false)
callMethod('abot.bg.setPosition', {getProperty('gfGroup.x')-85, getProperty('gfGroup.y')+120})

makeAnimatedLuaSprite('abotBody', 'characters/abotPixel/aBotPixelBody',getProperty('gfGroup.x')-100,getProperty('gfGroup.y')+100)
addAnimationByPrefix('abotBody', 'danceLeft', 'danceLeft', 24, false)
addAnimationByPrefix('abotBody', 'danceRight', 'danceRight', 24, false)
addAnimationByPrefix('abotBody', 'lowerKnife', 'return', 24, false)
scaleObject('abotBody', 6, 6)
callMethod('abotBody.origin.set', {callMethodFromClass('Math', 'round', {getProperty('abotBody.origin.x')}),callMethodFromClass('Math', 'round', {getProperty('abotBody.origin.y')})}) 
setProperty('abotBody.antialiasing', false)
addLuaSprite('abotBody')

positionX = {0, 7*6, 8*6, 9*6, 10*6, 6*6, 7*6}
positionY = {0, -2*6, -1*6, 0, 0, 1*6, 2*6}
posX = 0
posY = 0
for i = 0, getProperty('abot.vizSprites.length')-1 do
xd='abot.vizSprites['..i..']'
posX = posX + positionX[i+1]
posY = posY + positionY[i+1]
leX = getProperty(xd..'.x')
leY = getProperty(xd..'.y')
loadFrames(xd, 'characters/abotPixel/aBotVizPixel')
scaleObject(xd, 6, 6)
setProperty(xd..'.antialiasing', false)
callMethod(xd..'.setPosition', {posX+546, posY+530})
callMethod(xd..'.animation.addByPrefix', {'VIZ', 'viz'..(i+1), 0})
callMethod(xd..'.animation.play', {'VIZ'})
callMethod(xd..'.animation.curAnim.finish', {''})
end

function onSongStart()
setProperty('abot.snd', instanceArg('sound.music', 'flixel.FlxG'), false, true)
end

function onCountdownTick(t)
playAnim('abotSpeaker', 'danceLeft', true)
playAnim('abotBody', 'dance'..(t % 2 == 0 and 'Left' or 'Right'), true)
end

function onBeatHit()
playAnim('abotSpeaker', 'danceLeft', true)
playAnim('abotBody', 'dance'..(curBeat % 2 == 0 and 'Left' or 'Right'), true)
end