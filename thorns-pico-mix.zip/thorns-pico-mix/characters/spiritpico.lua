if not lowQuality then
createInstance('dadTrail','flixel.addons.effects.FlxTrail',{instanceArg('dad'),nil, 4, 24, 0.3, 0.069})
setObjectOrder('dadTrail',getObjectOrder('dadGroup')-1)
end