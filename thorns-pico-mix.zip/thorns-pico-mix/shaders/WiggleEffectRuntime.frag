#pragma header

uniform float uSpeed;
uniform float uFrequency;
uniform float uWaveAmplitude;
uniform float uTime;
uniform int effectType; // 0 = DREAMY, 1 = WAVY, 2 = HEAT_WAVE_HORIZONTAL, 3 = HEAT_WAVE_VERTICAL, 4 = FLAG

void main() {
    vec2 uv = openfl_TextureCoordv;
    float offset = 0.0;

    if(effectType == 0) { // DREAMY
        offset = sin(uv.y * uFrequency + uTime * uSpeed) * uWaveAmplitude;
        uv.x += offset;
        offset = cos(uv.x * uFrequency + uTime * uSpeed) * uWaveAmplitude;
        uv.y += offset;
    } else if(effectType == 1) { // WAVY
        offset = sin(uv.y * uFrequency + uTime * uSpeed) * uWaveAmplitude;
        uv.x += offset;
    } else if(effectType == 2) { // HEAT_WAVE_HORIZONTAL
        offset = sin(uv.y * uFrequency + uTime * uSpeed) * uWaveAmplitude;
        uv.x += offset;
    } else if(effectType == 3) { // HEAT_WAVE_VERTICAL
        offset = sin(uv.x * uFrequency + uTime * uSpeed) * uWaveAmplitude;
        uv.y += offset;
    } else if(effectType == 4) { // FLAG
        offset = sin(uv.y * uFrequency + uTime * uSpeed) * uWaveAmplitude;
        uv.x += offset;
        offset = sin(uv.x * uFrequency * 2.0 + uTime * uSpeed * 1.5) * uWaveAmplitude * 0.5;
        uv.y += offset;
    }

    gl_FragColor = flixel_texture2D(bitmap, uv);
}