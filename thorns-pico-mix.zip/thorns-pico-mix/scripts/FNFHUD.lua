p,es,og,frames,prevAnim=50,0,getPropertyFromClass('backend.ClientPrefs', 'data.comboOffset'),{0,0,0,0},{'','','',''}
setPropertyFromClass('backend.ClientPrefs', 'data.comboOffset',{0,0,55,50})
if getPropertyFromClass('states.PlayState','isPixelStage') then
runHaxeCode('grpNoteSplashes.memberAdded.add(function(s:FlxSprite) {s.blend = 0;});')
setProperty("camGame.pixelPerfectRender", true)
setProperty("camHUD.pixelPerfectRender", true)
end

function onCountdownStarted()
if not middlescroll then
for i = 0,7 do
setProperty('strumLineNotes.members['..i..'].x',getProperty('strumLineNotes.members['..i..'].x')-47)
end
end
end

function onCreatePost()
setObjectCamera('comboGroup')
setProperty('comboGroup.x',360)
setProperty('comboGroup.y',120)
setProperty('botplayTxt.visible',false)
runHaxeCode('game.updateIconsScale=function(){}')
setProperty('timeBar.visible',false)
setProperty('timeTxt.visible',false)

callMethod('scoreTxt.setPosition',{148,downscroll and 103 or 678})
setTextSize('scoreTxt',16)
setTextBorder('scoreTxt',0.4,'000000')
setProperty('scoreTxt.antialiasing',true)
setProperty('healthBar.y', screenHeight * (downscroll and 0.1 or 0.9))
setProperty('iconP1.y', getProperty('healthBar.y') - (getProperty('iconP1.height')+30))
setProperty('iconP2.y', getProperty('healthBar.y') - (getProperty('iconP2.height')+30))
setProperty('camZoomingMult',0)
setProperty('camZooming',true)
setProperty('iconP2.antialiasing',false)
end

function onSongStart()
setProperty('cameraSpeed',1)
end

function onUpdateScore()
if scoreZoom then
callMethod('scoreTxtTween.cancel')
end
setTextString('scoreTxt',botPlay and 'Bot Play Enabled' or 'Score: '..callMethodFromClass('flixel.util.FlxStringUtil', 'formatMoney', {score,false}))
end


function onUpdatePost(e)
if not inGameOver then
for i = 1,2 do
if getProperty('iconP'..i..'.graphic.width') > 64 then
setProperty('iconP'..i..'.animation.curAnim.curFrame',getHealth() > 1.6 and (i == 1 and 2 or 1) or getHealth() < 0.4 and (i == 2 and 2 or 1) or 0)
end
end

p = lerp(p, math.max(getHealth()*50,0), e*5)
q = (flip and p or w(p,0,100,100,0)) * 0.01
j = getProperty('healthBar.x') + getProperty('healthBar.width') * q
setProperty('healthBar.percent',math.min(p,100))
setProperty('iconP1.x',j+(150*getProperty('iconP1.scale.x')-710)/2-26)
setProperty('iconP2.x',j-(150*getProperty('iconP2.scale.x')-650)/2-26*2)
es = lerp(es, score, e * (stringEndsWith(wawa, 'end') and 20 or 1))
if jaja then
setTextString('scoreTxt',botPlay and 'Bot Play Enabled' or 'Score: '..callMethodFromClass('flixel.util.FlxStringUtil', 'formatMoney', {math.floor(es),false}))
end
end

for i = 0,7 do
anim = getPropertyFromGroup('strumLineNotes',i,'animation.name')
if anim == 'confirm' then
if anim ~= prevAnim[i+1] then
runTimer('StrumAnimAdvanceFrame'..i,1/24,0)
end
setPropertyFromGroup('strumLineNotes',i,'animation.curAnim.curFrame',frames[i+1])
else
cancelTimer('StrumAnimAdvanceFrame'..i)
frames[i+1] = 0
end
prevAnim[i+1] = anim
end

for a = 0, 3 do
strum = 'playerStrums.members['..a..']'
animName = getProperty(strum..'.animation.name')
if animName == 'confirm' and getProperty(strum..'.animation.finished') then
isHolding = false
for n = 0, getProperty('notes.length') - 1 do
if getPropertyFromGroup('notes', n, 'mustPress') and getPropertyFromGroup('notes', n, 'noteData') == a and getPropertyFromGroup('notes', n, 'isSustainNote')and getPropertyFromGroup('notes', n, 'strumTime') <= getSongPosition() + 100 then
isHolding = true
break
end
end
if not isHolding then
callMethod(strum..'.playAnim', {'pressed'})
end
end
end
end

function onTimerCompleted(t)
if stringStartsWith(t,'StrumAnimAdvanceFrame') then
n = t:gsub('StrumAnimAdvanceFrame','')
num = tonumber(n)
frame = frames[num+1]
if frame < getPropertyFromGroup('strumLineNotes',num,'animation.curAnim.numFrames') then
frames[num+1] = frames[num+1]+1
end
end
end

function noteMiss()
jaja=false
end

function lerp(a,b,t) return(b-a)*t+a end
function w(v,j,u,a,n) return a+(v-j)*((n-a)/(u-j)) end

function goodNoteHit(i,d,_,s)
jaja=s
wawa=getPropertyFromGroup('notes', i, 'animation.name')
end

function goodNoteHitPre(i,d,t,s)
setProperty('showComboNum',combo>8)
char=getProperty('notes.members['..i..'].gfNote') and 'gf' or 'boyfriend'
if s then
setProperty('notes.members['..i..'].noAnimation',true)
setProperty(char..'.holdTimer',0)
end
end

function opponentNoteHitPre(i,d,t,s)
char2=getProperty('notes.members['..i..'].gfNote') and 'gf' or 'dad'
if s then
setProperty('notes.members['..i..'].noAnimation', true)
setProperty(char2..'.holdTimer', 0)
end
end

function opponentNoteHit(i,d,_,s)
if not stringEndsWith(getPropertyFromGroup('notes', i, 'animation.name'), 'end') and s then return end
setProperty('opponentStrums.members['..d..'].resetAnim',getRandomFloat(0.05,0.4))
end


function onBeatHit()
h=getHealth()
if h < 0.5 and not lw then 
playAnim('gf', 'knifeRaise', true)
lw=true
elseif h < 0.5 and getProperty('gf.animation.name') ~= 'knife' then
playAnim('gf', 'knife', true)
setProperty('gf.stunned', true)
elseif h >= 0.5 and lw then
playAnim('gf', 'knifelower', true)
setProperty('gf.stunned', false)
lw=false
end
if curBeat % 5 == 0 then
if h< 0.5 and getProperty('gf.animation.name') == 'knife' then
playAnim('gf', 'knife', true)
end
end

scaleObject('iconP1', 5.2,5.2,false)
scaleObject('iconP2', 5.2,5.2,false)
doTweenX('MOTHER','iconP1.scale',5,0.15)
doTweenY('FUCKER','iconP1.scale',5,0.15)
doTweenX('HIJO','iconP2.scale',5,0.15)
doTweenY('DETUPUTAMADRE','iconP2.scale',5,0.15)
end



function onDestroy()
setPropertyFromClass('backend.ClientPrefs', 'data.comboOffset',og)
end