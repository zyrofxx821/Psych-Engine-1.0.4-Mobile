function onStartCountdown()
if not allowCountdown and not seenCutscene then
allowCountdown = true

playSound('LunchboxScary')
makeLuaSprite('purpel')
makeGraphic('purpel',screenWidth,screenHeight,'ff1b31')
setObjectCamera('purpel','other')
addLuaSprite('purpel')

makeAnimatedLuaSprite('senpaiCrazy','senpaiCrazy',150,-140)
setObjectCamera('senpaiCrazy','other')
setProperty('senpaiCrazy.antialiasing',false)
scaleObject('senpaiCrazy',6,6)
setProperty('senpaiCrazy.alpha',0)
addLuaSprite('senpaiCrazy')

makeLuaSprite('white')
makeGraphic('white',1,1)
scaleObject('white', screenWidth, screenHeight)
setObjectCamera('white', 'other')
setProperty('white.alpha',0)
addLuaSprite('white')

makeLuaSprite('black')
makeGraphic('black',1,1, '000000')
scaleObject('black', screenWidth, screenHeight)
setObjectCamera('black', 'other')
addLuaSprite('black')
setProperty('black.alpha',0)

runTimer('alpha xd',0.3,10)
return Function_Stop
end
end

function onTimerCompleted(t,l,ll)
if t=='blackshit' then
removeLuaSprite('black')
startCountdown()
setProperty('blackst.alpha',1)
doTweenAlpha('xd','blackst',0,4,'cubeInOut')

elseif t=='whiteshit' then
setProperty('white.alpha',getProperty('white.alpha')+0.1)
if ll==0 then
runTimer('cut2',1)
end

elseif t=='cut' then
runTimer('blackshit',0.15,10)

elseif t=='cut2' then
setProperty('black.alpha',1)
runTimer('cut',1)

removeLuaSprite('senpaiCrazy')
removeLuaSprite('purpel')
removeLuaSprite('white')


elseif t=='alpha xd' then
setProperty('senpaiCrazy.alpha',getProperty('senpaiCrazy.alpha')+0.1)
if ll==0 then
runTimer('anim',0.03)
end

elseif t=='anim' then
addAnimationByPrefix('senpaiCrazy','idle','Senpai Pre Explosion instance 1',24,false)
playSound('Senpai_Dies')
runTimer('light',4)

elseif t=='light' then
runTimer('whiteshit',0.1,10)

end
end