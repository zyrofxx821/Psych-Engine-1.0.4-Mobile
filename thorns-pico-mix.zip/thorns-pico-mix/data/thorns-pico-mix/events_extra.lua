setProperty('skipCountdown',true)

function onCreatePost()
setProperty('camZoomingDecay',4)

makeLuaSprite('blackst')
makeGraphic('blackst',4000,2000)
setScrollFactor('blackst',0,0)
setBlendMode('blackst','SUBTRACT')
screenCenter('blackst')
addLuaSprite('blackst',true)
if seenCutscene then
doTweenAlpha('xd','blackst',0,6,'cubeInOut')
end

setProperty('camHUD.visible',false)


if shadersEnabled then
makeLuaSprite('ca',nil,0.2)
makeLuaSprite('efec',nil,0.8)
makeLuaSprite('str',nil,0.11)
makeLuaSprite('color')
setSpriteShader('color','adjustColor')
setShaderFloat('color','contrast',0)
setShaderFloat('color','hue',-20)
setShaderFloat('color','contrast',0)
setShaderFloat('color','brightness',0)

makeLuaSprite('bloom')
setSpriteShader('bloom','bloom')
setShaderFloat('bloom','effect',0)
setShaderFloat('bloom','strength',0)
setShaderFloat('bloom','contrast',1)
setShaderFloat('bloom','brightness',0)

makeLuaSprite('chromShader')
setSpriteShader('chromShader','Chrom')
runHaxeCode('camGame.filters=[new ShaderFilter(getVar("color").shader),new ShaderFilter(getVar("bloom").shader),new ShaderFilter(getVar("chromShader").shader)]; camHUD.filters=[new ShaderFilter(getVar("color").shader)];')
end
end

function onStepHit()
if curStep==191 or curStep==831 then
setProperty('camZoomingDecay',1)
triggerEvent('SetCameraBop',1,0.8)

elseif curStep==192 then
triggerEvent('Bloom','8,0.5')

elseif curStep==64 then
setProperty('camHUD.visible',true)

elseif curStep==432 then
triggerEvent('SetCameraBop',4,1)
doTweenAlpha('xd','blackst',1,1,'cubeIn')
doTweenX('ASFD','ca',2,1,'cubeIn')
cameraShake('game',0.0005,stepCrochet*0.001*128)
cameraShake('hud',0.0005,stepCrochet*0.001*128)

elseif curStep==447 then
cancelTween('xd')
setProperty('blackst.alpha',0.2)
setProperty('defaultCamZoom',1.2)
setProperty('camGame.zoom',1.2)

elseif curStep==575 then
triggerEvent('SetCameraBop',1,0.8)
setProperty('blackst.alpha',0)
doTweenX('sifilis','ca',0.2,crochet*0.001*3,'cubeOut')

elseif curStep==703 then
triggerEvent('SetCameraBop',4,1)
setProperty('camZoomingDecay',4)

elseif curStep==704 then
triggerEvent('Bloom','8,0.5')

elseif curStep==1088 then
triggerEvent('SetCameraBop',900,0)

elseif curStep==1148 then
setProperty('camGame.visible',false)
setProperty('camHUD.visible',false)
end
end

function onEvent(n,v1,v2)
if n=='Bloom' then
if shadersEnabled then
p = stringSplit(v1, ",")
va1 = p[1]
va2= p[2]

time=stepCrochet * 0.001 *va1
setProperty('efec.x',getProperty('efec.x')+va2)
setProperty('str.x',getProperty('str.x')+va2)
doTweenX('efecTween','efec',0.8,time)
doTweenX('strTween','str',0.11,time)
end end
end

function onUpdatePost()
if shadersEnabled then
setShaderFloat('bloom','effect',getProperty('efec.x'))
setShaderFloat('bloom','strength',getProperty('str.x'))
setShaderFloat('chromShader','ca',getProperty('ca.x'))
end
end