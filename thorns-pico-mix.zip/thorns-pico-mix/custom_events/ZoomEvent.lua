function onEvent(n,v1,v2)
if n=='ZoomEvent' then
palos = stringSplit(v1, ",")
palos1 = palos[1]
palos2= palos[2]
palos3= palos[3]
doTweenZoom('z',_,getProperty('defaultCamZoom')+palos1,stepCrochet * palos2 / 1000,palos3)
setProperty('defaultCamZoom',getProperty('defaultCamZoom')+palos1)
end
end