function onEvent(n,v1,v2)
if n=='BeatZoom' then
wawa = stringSplit(v1, ",")
wawa1 = wawa[1]
wawa2= wawa[2]
wawa3= wawa[3]
wawa4= wawa[4]

end
end

function onBeatHit()
if wawa1=='true' then
if curBeat%wawa3==wawa4 then
triggerEvent('Add Camera Zoom',wawa2+0.07,wawa3)
end
end
end