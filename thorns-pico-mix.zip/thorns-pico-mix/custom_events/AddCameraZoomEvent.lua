function onEvent(n,v1,v2)
if n=='AddCameraZoomEvent' then
palo = stringSplit(v1, ",")
palo1 = palo[1]
palo2= palo[2]
triggerEvent('Add Camera Zoom',palo2,palo1)
end
end