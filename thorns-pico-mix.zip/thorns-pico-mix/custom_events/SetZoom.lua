defZoom = getProperty('defaultCamZoom')

function onEvent(n,v1,v2)
if n == 'SetZoom' then
z = (v1 == '' and defZoom) or tonumber(v1) or defZoom
dur = 3
ez = 'smootherStepOut'

if v2 and v2 ~= '' then
p = stringSplit(v2, ',')
dur = tonumber(p[1]) or 7
ez = p[2] or 'smootherStepOut'
end

cancelTween('zoomCam')
if dur < 0.01 then
setProperty('defaultCamZoom', z)
setProperty('camGame.zoom', z)
else
setProperty('defaultCamZoom', z)
doTweenZoom('zoomCam', _, z, stepCrochet * 0.001 * dur, ez)
end
end
end