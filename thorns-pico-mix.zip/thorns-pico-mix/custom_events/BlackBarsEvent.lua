luaDebugMode=true
createInstance('SexCam','flixel.FlxCamera')
callMethod('SexCam.copyFrom',{instanceArg('camHUD')})
callMethodFromClass('flixel.FlxG','cameras.add',{instanceArg('SexCam'),false})
for _,m in pairs({'camHUD','camOther'}) do
callMethodFromClass('flixel.FlxG','cameras.remove',{instanceArg(m),false})
callMethodFromClass('flixel.FlxG','cameras.add',{instanceArg(m),false})
end
setProperty('SexCam.bgColor',0)

makeLuaSprite('topBar',nil,0,-500)
makeGraphic('topBar', 1,1, '000000')
scaleObject('topBar',screenWidth, 500)
addLuaSprite('topBar')

makeLuaSprite('botBar',nil,0,screenHeight)
makeGraphic('botBar', 1, 1, '000000')
scaleObject('botBar',screenWidth,500)
addLuaSprite('botBar')

setObjectCamera('topBar', 'SexCam')
setObjectCamera('botBar', 'SexCam')

function onEvent(n, v1, v2)
if n == 'BlackBarsEvent' then
xd = stringSplit(v1, ",")
xd1 = xd[1]
xd2= xd[2]
ez= xd[3]

doTweenY('moveTopBar', 'topBar', -500 + xd1, stepCrochet * 0.001 * xd2, ez)
doTweenY('moveBottomBar', 'botBar',screenHeight - xd1, stepCrochet * 0.001 * xd2, ez)
end
end
