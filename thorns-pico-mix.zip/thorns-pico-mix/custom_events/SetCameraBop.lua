local rate = 4
local intensity = 0
function onBeatHit()
if curBeat % rate == 0 then
triggerEvent('Add Camera Zoom',0.04*intensity,0.02*intensity)
end
end

function onEvent(n,v1,v2)
if n == 'SetCameraBop' then
rate = tonumber(v1)
intensity = tonumber(v2)
end
end