function z()
setPropertyFromClass('flixel.FlxG', 'camera.target', instanceArg('camFollow'), nil, true)
end

function getCharPos(char)
if char == '0' or char:lower() == 'bf' or char:lower() == 'boyfriend' then
playAnim('abotHead','toright')
return {x = getMidpointX('boyfriend') - getProperty('boyfriend.cameraPosition[0]') + getProperty('boyfriendCameraOffset[0]') - 100,y = getMidpointY('boyfriend') + getProperty('boyfriend.cameraPosition[1]') + getProperty('boyfriendCameraOffset[1]') - 100}

elseif char == '1' or char:lower() == 'dad' or char:lower() == 'opponent' then
playAnim('abotHead','toleft')
return {x = getMidpointX('dad') + getProperty('dad.cameraPosition[0]') + getProperty('opponentCameraOffset[0]') + 150,y = getMidpointY('dad') + getProperty('dad.cameraPosition[1]') + getProperty('opponentCameraOffset[1]') - 100}

elseif char == '2' or char:lower() == 'gf' or char:lower() == 'girlfriend' then
return {x = getMidpointX('gf') + getProperty('gf.cameraPosition[0]') + getProperty('girlfriendCameraOffset[0]'),y = getMidpointY('gf') + getProperty('gf.cameraPosition[1]') + getProperty('girlfriendCameraOffset[1]')}
end
return {x = 0, y = 0}
end

function snapCam(x, y)
z()
callMethod('camFollow.setPosition', {x, y})
callMethod('camGame.snapToTarget', {''})
end

function tweenCam(x, y, tData)
td = stringSplit(tData, ',')
if td[1] == '0' then
snapCam(x, y)
return
end

setPropertyFromClass('flixel.FlxG', 'camera.target')
callMethod('camFollow.setPosition', {x - screenWidth / 2, y - screenHeight / 2})
dur = stepCrochet * tonumber(td[1]) / 1000
ease = td[2] or 'smootherStepOut' or td[2]

if dur < 0.01 then ease = 'linear' dur = 0.001
elseif ease == 'CLASSIC' then ease = 'expoOut' dur = dur + 1
elseif ease == 'INSTANT' or ease == 'INSTANTIn' or ease == 'INSTANTOut' or ease == 'INSTANTInOut' then ease = 'linear' dur = 0.001 end

doTweenX('moveCameraX', 'camGame.scroll', getProperty('camFollow.x'), dur, ease)
doTweenY('moveCameraY', 'camGame.scroll', getProperty('camFollow.y'), dur, ease)
end

function onTweenCompleted(t)
if t == 'moveCameraX' or t == 'moveCameraY' then
z()
callMethod('camFollow.setPosition', {getProperty('camGame.scroll.x') + screenWidth / 2, getProperty('camGame.scroll.y') + screenHeight / 2})
end
end

function onEvent(n, v1, v2)
if n ~= 'FocusCamera' then return end
cancelTween('moveCameraX')
cancelTween('moveCameraY')
if v1 == '' then
setProperty('isCameraOnForcedPos', false)
z()
else
setProperty('isCameraOnForcedPos', true)

tData = stringSplit(v1, ',')
pos = getCharPos(tData[1])

if tData[2] then
pos.x = pos.x + tonumber(tData[2])
if tData[3] then pos.y = pos.y + tonumber(tData[3]) end
end

if v2 == '' then snapCam(pos.x, pos.y) else tweenCam(pos.x, pos.y, v2) end
end
end