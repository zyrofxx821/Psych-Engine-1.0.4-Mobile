WSPEED=1
WFREQ=4
WAMP=0.016
treeNames={'treesBack', 'trees'}
treeSwayAmp={22,18}
treeSwaySpeed={0.8,1.2}
treeSwayPhase={0,1.5}
treeProps={}
treeBaseY={}
swayTime=0

if not lowQuality then
createInstance('sky','flixel.addons.display.FlxBackdrop', {nil, 0x11})
loadGraphic('sky','stages/schoolExtraEvil/schoolEXTRA_EVIL-sky')
callMethod('sky.setPosition',{-563,-309})
scaleObject('sky',8,8)
setProperty('sky.antialiasing',false)
addInstance('sky')
callMethod('sky.velocity.set',{68, -68})
end

makeAnimatedLuaSprite('school','stages/schoolExtraEvil/schoolEXTRA_EVIL-sprites',-590,-135)
scaleObject('school',6,6)
addAnimationByPrefix('school','idle','evilSchool',24,true)
setProperty('school.antialiasing',false)
addLuaSprite('school')

if shadersEnabled then
setSpriteShader('school','WiggleEffectRuntime')
setShaderFloat('school','uSpeed',WSPEED)
setShaderFloat('school','uFrequency',WFREQ)
setShaderFloat('school','uWaveAmplitude',WAMP * 0.14)
setShaderInt('school','effectType',0)
end

makeAnimatedLuaSprite('grass','stages/schoolExtraEvil/schoolEXTRA_EVIL-sprites',-487,-372)
scaleObject('grass',5,8.15)
setProperty('grass.color',getColorFromHex('DD0225'))
addAnimationByPrefix('grass','idle','weebStreetss',24,true)
setProperty('grass.antialiasing',false)
addLuaSprite('grass')

makeAnimatedLuaSprite('street2','stages/schoolExtraEvil/schoolEXTRA_EVIL-sprites',-487,980)
scaleObject('street2',5,8)
setProperty('street2.flipY',true)
addAnimationByPrefix('street2','idle','evilStreet',24,true)
setProperty('street2.antialiasing',false)
addLuaSprite('street2')

makeAnimatedLuaSprite('spikes','stages/schoolExtraEvil/schoolEXTRA_EVIL-sprites',-1566,-349)
scaleObject('spikes',8,9)
setProperty('spikes.color',getColorFromHex('FF2151'))
addAnimationByPrefix('spikes','idle','weebBackSpikes',24,true)
setProperty('spikes.antialiasing',false)
addLuaSprite('spikes')

makeAnimatedLuaSprite('trees','stages/schoolExtraEvil/schoolEXTRA_EVIL-sprites',-487,6)
scaleObject('trees',5,5)
addAnimationByPrefix('trees','idle','evilTrees',24,true)
setProperty('trees.antialiasing',false)
addLuaSprite('trees')

makeAnimatedLuaSprite('street','stages/schoolExtraEvil/schoolEXTRA_EVIL-sprites',-487,-352)
scaleObject('street',5,8)
addAnimationByPrefix('street','idle','evilStreet',24,true)
addLuaSprite('street')
setProperty('street.antialiasing',false)

makeAnimatedLuaSprite('treesBack','stages/schoolExtraEvil/schoolEXTRA_EVIL-sprites',-410.5,-155)
scaleObject('treesBack',7,7)
addAnimationByPrefix('treesBack','idle','weebTreesBackEvil',24,true)
addLuaSprite('treesBack')
setProperty('treesBack.antialiasing',false)

makeAnimatedLuaSprite('trees2','stages/schoolExtraEvil/treesAndPetals',-602,-901)
scaleObject('trees2',5,5)
setScrollFactor('trees2',0.9,0.9)
setProperty('trees2.color',getColorFromHex('A30225'))
addAnimationByPrefix('trees2','idle','weebTrees dance',24,true)
addLuaSprite('trees2')
setProperty('trees2.antialiasing',false)

makeAnimatedLuaSprite('treesAgain','stages/schoolExtraEvil/treesAndPetals',-1114,-1317)
scaleObject('treesAgain',7,7)
setProperty('treesAgain.color',getColorFromHex('EB0537'))
addAnimationByPrefix('treesAgain','idle','weebTrees dance',24,true)
addLuaSprite('treesAgain')
setProperty('treesAgain.antialiasing',false)

makeAnimatedLuaSprite('trees3','stages/schoolExtraEvil/treesAndPetals',-1370,-1800)
scaleObject('trees3',8,8)
setScrollFactor('trees3',0.9,0.9)
setProperty('trees3.color',getColorFromHex('A30225'))
addAnimationByPrefix('trees3','idle','weebTrees dance',24,true)
addLuaSprite('trees3')
setProperty('trees3.antialiasing',false)

makeAnimatedLuaSprite('petals','stages/schoolExtraEvil/treesAndPetals',-99.5,122)
scaleObject('petals',5,5)
setProperty('petals.color',getColorFromHex('FF2151'))
addAnimationByPrefix('petals','idle','PETALS ALL0',18,true)
addLuaSprite('petals',true)
setProperty('petals.antialiasing',false)

makeLuaSprite('light','stages/schoolExtraEvil/schoolEXTRA_EVIL-light',-2085,-4129)
scaleObject('light',6,6)
setBlendMode('light','overlay')
setProperty('light.color',getColorFromHex('F71B4B'))
addLuaSprite('light',true)
setProperty('light.antialiasing',false)

for k = 1, #treeNames do
table.insert(treeProps, treeNames[k])
table.insert(treeBaseY, getProperty(treeNames[k]..'.y'))
end


function onUpdate(e)
swayTime=swayTime+e

if inGameOver then
scaleObject('subState.members[0]', 6, 6,false)
setProperty('subState.members[0].antialiasing',false)
else
currentBeat = (getSongPosition()/10000)*(bpm/100)

for i=0,3 do
setProperty('strumLineNotes.members['..i..'].y', _G['defaultOpponentStrumY'..i] - 20 * math.sin((currentBeat + i * 0.3) * math.pi))
end
for k = 1, #treeProps do
tree = treeProps[k]
setProperty(tree..'.y', treeBaseY[k] + math.sin(swayTime * treeSwaySpeed[k] + treeSwayPhase[k]) * treeSwayAmp[k])
end
setProperty('dad.y',getProperty('dad.y') - math.sin(swayTime * 0.8) * 0.4)

if shadersEnabled then
setShaderFloat('school','uTime',swayTime)
end

end
end
